#!/usr/bin/env bash
# Installe le thème GRUB NOOS : ./install.sh [RACINE] [--mkconfig]
#
# - copie le thème dans RACINE/boot/grub/themes/noos (GRUB lit /boot, pas /usr) ;
# - règle GRUB_THEME, GRUB_TERMINAL_OUTPUT=gfxterm et GRUB_GFXMODE dans /etc/default/grub ;
# - --mkconfig : régénère /boot/grub/grub.cfg (update-grub charge alors les polices .pf2
#   du thème). L'installateur, lui, régénère grub.cfg à la fin de son étape GRUB.
#
# Utilisé par l'installateur (chroot du système installé), le paquet Debian (postinst) et à la main.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="/"
MKCONFIG=0
for a in "$@"; do
    case "$a" in
    --mkconfig) MKCONFIG=1 ;;
    *) ROOT="$a" ;;
    esac
done
SRC="$HERE/noos"
[ -f "$SRC/theme.txt" ] || SRC="$HERE"    # copie installée : fichiers à côté du script
DEST="$ROOT/boot/grub/themes/noos"
install -d "$DEST"
for f in "$SRC"/theme.txt "$SRC"/*.png "$SRC"/*.pf2; do
    install -m644 "$f" "$DEST/"
done

DEFAULT="$ROOT/etc/default/grub"
install -d "$(dirname "$DEFAULT")"
touch "$DEFAULT"
set_key() {
    if grep -q "^$1=" "$DEFAULT"; then
        sed -i "s|^$1=.*|$1=\"$2\"|" "$DEFAULT"
    else
        echo "$1=\"$2\"" >>"$DEFAULT"
    fi
}
set_key GRUB_THEME "/boot/grub/themes/noos/theme.txt"
set_key GRUB_TERMINAL_OUTPUT "gfxterm"
grep -q '^GRUB_GFXMODE=' "$DEFAULT" || set_key GRUB_GFXMODE "auto"

# Fond de la console (pas de rectangle noir au lancement d'une entrée) : grub.cfg est
# régénéré si ce morceau est nouveau ou a changé.
SNIP="$ROOT/etc/grub.d/05_noos_background"
if ! cmp -s "$HERE/05_noos_background" "$SNIP" 2>/dev/null; then
    install -Dm755 "$HERE/05_noos_background" "$SNIP"
    MKCONFIG=1
fi

if [ "$MKCONFIG" = 1 ]; then
    if [ "$ROOT" = "/" ]; then
        grub-mkconfig -o /boot/grub/grub.cfg >/dev/null 2>&1
    else
        chroot "$ROOT" grub-mkconfig -o /boot/grub/grub.cfg >/dev/null 2>&1
    fi
fi
echo "Thème GRUB NOOS installé dans $DEST"
